"""
Train 6 regression models for health insurance price prediction.
Generates 8 EDA charts and saves the best model.
"""
import pandas as pd
import numpy as np
import os
import json
import joblib
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

BASE_DIR = os.path.dirname(__file__)
VIS_DIR = os.path.join(BASE_DIR, 'static', 'vis')
os.makedirs(VIS_DIR, exist_ok=True)

# Dark theme for charts
plt.rcParams.update({
    'figure.facecolor': '#0f172a',
    'axes.facecolor': '#1e293b',
    'axes.edgecolor': '#334155',
    'axes.labelcolor': '#e2e8f0',
    'text.color': '#e2e8f0',
    'xtick.color': '#94a3b8',
    'ytick.color': '#94a3b8',
    'grid.color': '#334155',
    'grid.alpha': 0.5
})

ACCENT = '#0ea5e9'
ACCENT2 = '#38bdf8'
ACCENT3 = '#7dd3fc'

# --- Load data ---
df = pd.read_csv(os.path.join(BASE_DIR, 'insurance_data.csv'))
print(f"Loaded dataset: {df.shape}")

# --- EDA Charts ---
def save_chart(fig, name):
    path = os.path.join(VIS_DIR, name)
    fig.savefig(path, dpi=120, bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close(fig)
    print(f"  Saved: {name}")

print("\nGenerating EDA charts...")

# 1. Age vs Charges scatter
fig, ax = plt.subplots(figsize=(10, 6))
colors = [ACCENT if s == 'no' else '#f43f5e' for s in df['smoker']]
ax.scatter(df['age'], df['charges'], c=colors, alpha=0.4, s=10)
ax.set_xlabel('Age', fontsize=12)
ax.set_ylabel('Charges ($)', fontsize=12)
ax.set_title('Age vs Insurance Charges', fontsize=14, fontweight='bold')
from matplotlib.lines import Line2D
legend_elements = [Line2D([0], [0], marker='o', color='w', markerfacecolor=ACCENT, markersize=8, label='Non-Smoker'),
                   Line2D([0], [0], marker='o', color='w', markerfacecolor='#f43f5e', markersize=8, label='Smoker')]
ax.legend(handles=legend_elements, loc='upper left')
ax.grid(True, alpha=0.3)
save_chart(fig, 'age_vs_charges.png')

# 2. BMI vs Charges (colored by smoker)
fig, ax = plt.subplots(figsize=(10, 6))
ax.scatter(df[df['smoker'] == 'no']['bmi'], df[df['smoker'] == 'no']['charges'], c=ACCENT, alpha=0.4, s=10, label='Non-Smoker')
ax.scatter(df[df['smoker'] == 'yes']['bmi'], df[df['smoker'] == 'yes']['charges'], c='#f43f5e', alpha=0.4, s=10, label='Smoker')
ax.set_xlabel('BMI', fontsize=12)
ax.set_ylabel('Charges ($)', fontsize=12)
ax.set_title('BMI vs Insurance Charges', fontsize=14, fontweight='bold')
ax.legend()
ax.grid(True, alpha=0.3)
save_chart(fig, 'bmi_vs_charges.png')

# 3. Smoker vs Charges box plot
fig, ax = plt.subplots(figsize=(8, 6))
bp = ax.boxplot([df[df['smoker'] == 'no']['charges'], df[df['smoker'] == 'yes']['charges']],
                labels=['Non-Smoker', 'Smoker'], patch_artist=True,
                boxprops=dict(facecolor=ACCENT, alpha=0.7),
                medianprops=dict(color='#fbbf24', linewidth=2),
                whiskerprops=dict(color='#94a3b8'),
                capprops=dict(color='#94a3b8'),
                flierprops=dict(markerfacecolor='#f43f5e', markersize=3))
bp['boxes'][1].set_facecolor('#f43f5e')
ax.set_ylabel('Charges ($)', fontsize=12)
ax.set_title('Smoker vs Non-Smoker Charges', fontsize=14, fontweight='bold')
ax.grid(True, alpha=0.3, axis='y')
save_chart(fig, 'smoker_boxplot.png')

# 4. Region vs Charges box plot
fig, ax = plt.subplots(figsize=(10, 6))
region_data = [df[df['region'] == r]['charges'] for r in ['northeast', 'northwest', 'southeast', 'southwest']]
region_colors = [ACCENT, ACCENT2, ACCENT3, '#06b6d4']
bp = ax.boxplot(region_data, labels=['Northeast', 'Northwest', 'Southeast', 'Southwest'],
                patch_artist=True, medianprops=dict(color='#fbbf24', linewidth=2),
                whiskerprops=dict(color='#94a3b8'), capprops=dict(color='#94a3b8'),
                flierprops=dict(markerfacecolor='#f43f5e', markersize=3))
for patch, color in zip(bp['boxes'], region_colors):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)
ax.set_ylabel('Charges ($)', fontsize=12)
ax.set_title('Insurance Charges by Region', fontsize=14, fontweight='bold')
ax.grid(True, alpha=0.3, axis='y')
save_chart(fig, 'region_boxplot.png')

# 5. Feature correlation heatmap
fig, ax = plt.subplots(figsize=(10, 8))
df_encoded = df.copy()
for col in ['sex', 'smoker', 'region']:
    df_encoded[col] = LabelEncoder().fit_transform(df_encoded[col])
corr = df_encoded.corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, mask=mask, annot=True, fmt='.2f', cmap='coolwarm', center=0,
            ax=ax, linewidths=1, linecolor='#334155',
            cbar_kws={'label': 'Correlation'},
            annot_kws={'fontsize': 11, 'fontweight': 'bold'})
ax.set_title('Feature Correlation Heatmap', fontsize=14, fontweight='bold')
save_chart(fig, 'correlation_heatmap.png')

# 6. Charges distribution histogram
fig, ax = plt.subplots(figsize=(10, 6))
ax.hist(df['charges'], bins=50, color=ACCENT, alpha=0.7, edgecolor='#1e293b')
ax.axvline(df['charges'].mean(), color='#fbbf24', linestyle='--', linewidth=2, label=f"Mean: ${df['charges'].mean():,.0f}")
ax.axvline(df['charges'].median(), color='#f43f5e', linestyle='--', linewidth=2, label=f"Median: ${df['charges'].median():,.0f}")
ax.set_xlabel('Charges ($)', fontsize=12)
ax.set_ylabel('Frequency', fontsize=12)
ax.set_title('Distribution of Insurance Charges', fontsize=14, fontweight='bold')
ax.legend(fontsize=11)
ax.grid(True, alpha=0.3, axis='y')
save_chart(fig, 'charges_distribution.png')

# --- Preprocessing ---
print("\nPreprocessing data...")
le_sex = LabelEncoder()
le_smoker = LabelEncoder()
le_region = LabelEncoder()

df['sex_encoded'] = le_sex.fit_transform(df['sex'])
df['smoker_encoded'] = le_smoker.fit_transform(df['smoker'])
df['region_encoded'] = le_region.fit_transform(df['region'])

feature_cols = ['age', 'sex_encoded', 'bmi', 'children', 'smoker_encoded', 'region_encoded']
X = df[feature_cols].values
y = df['charges'].values

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42)
print(f"Train: {X_train.shape[0]}, Test: {X_test.shape[0]}")

# --- Train 6 models ---
models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(alpha=1.0),
    'Lasso Regression': Lasso(alpha=1.0),
    'SVR': SVR(kernel='rbf', C=100, gamma='scale'),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=200, max_depth=5, random_state=42)
}

results = {}
best_r2 = -999
best_name = None

print("\nTraining models...")
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))

    results[name] = {'r2': round(r2 * 100, 2), 'mae': round(mae, 2), 'rmse': round(rmse, 2)}
    print(f"  {name}: R²={r2*100:.2f}%, MAE=${mae:,.2f}, RMSE=${rmse:,.2f}")

    if r2 > best_r2:
        best_r2 = r2
        best_name = name
        best_model = model

print(f"\nBest model: {best_name} (R²={best_r2*100:.2f}%)")

# --- Save model artifacts ---
joblib.dump(best_model, os.path.join(BASE_DIR, 'best_model.pkl'))
joblib.dump({'sex': le_sex, 'smoker': le_smoker, 'region': le_region}, os.path.join(BASE_DIR, 'encoders.pkl'))
joblib.dump(scaler, os.path.join(BASE_DIR, 'scaler.pkl'))

models_info = {
    'best_model': best_name,
    'best_r2': results[best_name]['r2'],
    'results': results,
    'feature_cols': ['age', 'sex', 'bmi', 'children', 'smoker', 'region'],
    'dataset_size': len(df),
    'train_size': len(X_train),
    'test_size': len(X_test)
}
with open(os.path.join(BASE_DIR, 'models_info.json'), 'w') as f:
    json.dump(models_info, f, indent=2)

print("Saved: best_model.pkl, encoders.pkl, scaler.pkl, models_info.json")

# --- Chart 7: Model R² comparison ---
fig, ax = plt.subplots(figsize=(10, 6))
names = list(results.keys())
r2_vals = [results[n]['r2'] for n in names]
colors_bar = [ACCENT if n != best_name else '#22c55e' for n in names]
bars = ax.barh(names, r2_vals, color=colors_bar, edgecolor='#1e293b', height=0.6)
for bar, val in zip(bars, r2_vals):
    ax.text(bar.get_width() + 0.3, bar.get_y() + bar.get_height()/2, f'{val}%',
            va='center', fontsize=11, fontweight='bold', color='#e2e8f0')
ax.set_xlabel('R² Score (%)', fontsize=12)
ax.set_title('Model R² Score Comparison', fontsize=14, fontweight='bold')
ax.set_xlim(0, 105)
ax.grid(True, alpha=0.3, axis='x')
save_chart(fig, 'model_r2_comparison.png')

# --- Chart 8: MAE / RMSE comparison ---
fig, ax = plt.subplots(figsize=(12, 6))
x_pos = np.arange(len(names))
width = 0.35
mae_vals = [results[n]['mae'] for n in names]
rmse_vals = [results[n]['rmse'] for n in names]
ax.bar(x_pos - width/2, mae_vals, width, label='MAE', color=ACCENT, edgecolor='#1e293b')
ax.bar(x_pos + width/2, rmse_vals, width, label='RMSE', color='#f43f5e', edgecolor='#1e293b')
ax.set_xticks(x_pos)
ax.set_xticklabels(names, rotation=20, ha='right', fontsize=10)
ax.set_ylabel('Error ($)', fontsize=12)
ax.set_title('Model MAE & RMSE Comparison', fontsize=14, fontweight='bold')
ax.legend(fontsize=11)
ax.grid(True, alpha=0.3, axis='y')
save_chart(fig, 'model_error_comparison.png')

print("\nTraining complete! All artifacts saved.")
