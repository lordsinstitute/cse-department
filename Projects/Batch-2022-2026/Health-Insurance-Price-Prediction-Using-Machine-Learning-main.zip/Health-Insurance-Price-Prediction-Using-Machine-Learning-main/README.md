# Health Insurance Price Prediction Using Machine Learning

A Flask web application that predicts health insurance charges based on personal factors using 6 regression algorithms. Enter your age, BMI, smoking status, and other details to get an instant insurance cost estimate with a color-coded risk rating.

## Features

- **Instant Price Prediction** — Enter 6 personal details to get predicted insurance charges
- **6 ML Models Compared** — Linear Regression, Ridge, Lasso, SVR, Random Forest, Gradient Boosting
- **Cost Rating System** — Color-coded 1-10 rating (Low/Moderate/High/Very High)
- **Prediction History** — Track all past predictions per user
- **Model Dashboard** — Side-by-side comparison of all 6 models with Chart.js charts
- **EDA Visualizations** — 8 training data analysis charts
- **User Authentication** — Login/register with password hashing

## Model Performance

| Algorithm | R² Score | MAE | RMSE |
|-----------|----------|-----|------|
| **Ridge Regression** | **92.60%** | **$2,264.59** | **$3,306.26** |
| Linear Regression | 92.60% | $2,264.69 | $3,306.28 |
| Lasso Regression | 92.60% | $2,264.63 | $3,306.28 |
| SVR | 75.32% | $3,572.59 | $6,036.89 |
| Random Forest | 91.78% | $2,348.57 | $3,483.79 |
| Gradient Boosting | 91.99% | $2,301.73 | $3,439.42 |

## Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

## Installation (Windows)

1. **Clone the repository:**
```bash
git clone <repository-url>
cd code
```

2. **Create a virtual environment (recommended):**
```bash
python -m venv venv
venv\Scripts\activate
```

3. **Install dependencies:**
```bash
pip install -r requirements.txt
```

4. **Generate the dataset:**
```bash
python generate_dataset.py
```

5. **Train the models:**
```bash
python train_model.py
```

6. **Run the application:**
```bash
python app.py
```
Open http://localhost:5015 in your browser.

7. **Login:**
- Username: `admin`
- Password: `admin123`

## Docker Deployment

```bash
docker build -t insurance-prediction .
docker run -p 5015:5015 insurance-prediction
```

## Input Features

| Feature | Type | Range |
|---------|------|-------|
| Age | Numeric | 18 – 64 |
| Sex | Categorical | Male, Female |
| BMI | Numeric | 16.0 – 53.0 |
| Children | Numeric | 0 – 5 |
| Smoker | Categorical | Yes, No |
| Region | Categorical | Northeast, Northwest, Southeast, Southwest |

## Cost Rating System

| Rating | Label | Color | Charges Range |
|--------|-------|-------|---------------|
| 1–3 | Low Cost | Green | Under $10,000 |
| 4–6 | Moderate Cost | Yellow | $10,000 – $25,000 |
| 7–8 | High Cost | Orange | $25,000 – $40,000 |
| 9–10 | Very High Cost | Red | Over $40,000 |

## Project Structure

```
code/
├── app.py                     # Flask app with all routes
├── generate_dataset.py        # Synthetic insurance dataset (5,000 rows)
├── train_model.py             # 6 regression models + EDA charts
├── static/vis/                # Training-generated charts
├── templates/
│   ├── base.html              # Sky blue dark theme
│   ├── login.html             # Login page
│   ├── register.html          # Registration page
│   ├── home.html              # Dashboard with stats
│   ├── predict.html           # Insurance form + result
│   ├── history.html           # Past predictions
│   ├── dashboard.html         # Model comparison (Chart.js)
│   └── about.html             # Project info
├── Dockerfile
├── requirements.txt
└── .gitignore
```

## Test Cases

1. Login as admin/admin123 → dashboard with stat cards
2. Predict with young non-smoker (25/F/BMI 22) → low charges (~$14K)
3. Predict with older smoker (55/M/BMI 35) → very high charges (~$59K)
4. Prediction result shows color-coded rating badge
5. History page shows past predictions with ratings
6. Dashboard shows 6-model comparison table and Chart.js charts
7. EDA charts display in dashboard gallery
8. About page shows pipeline, tech stack, model descriptions
9. Register new user → redirect to login with success message
10. Duplicate username → error message
11. Access /predict without login → redirect to login
12. Admin sees extra stats (total users, total predictions)

## Technology Stack

- **Backend:** Python, Flask
- **ML:** scikit-learn (6 regression algorithms)
- **Preprocessing:** LabelEncoder, StandardScaler
- **Data:** Pandas, NumPy
- **Charts:** Chart.js (frontend), Matplotlib/Seaborn (training)
- **Frontend:** Bootstrap 5, Bootstrap Icons
- **Database:** SQLite
