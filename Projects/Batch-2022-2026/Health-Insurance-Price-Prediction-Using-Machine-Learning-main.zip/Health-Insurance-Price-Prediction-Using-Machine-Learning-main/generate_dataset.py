"""
Generate synthetic health insurance dataset (5,000 rows).
Mimics the Kaggle insurance.csv structure with realistic charge calculations.
"""
import pandas as pd
import numpy as np
import os

np.random.seed(42)

NUM_SAMPLES = 5000

# --- Feature generation ---
ages = np.random.randint(18, 65, NUM_SAMPLES)
sexes = np.random.choice(['male', 'female'], NUM_SAMPLES, p=[0.5, 0.5])
bmis = np.round(np.random.normal(30.5, 6.0, NUM_SAMPLES).clip(16.0, 53.0), 1)
children_arr = np.random.choice([0, 1, 2, 3, 4, 5], NUM_SAMPLES, p=[0.35, 0.25, 0.20, 0.10, 0.06, 0.04])
smokers = np.random.choice(['yes', 'no'], NUM_SAMPLES, p=[0.20, 0.80])
regions = np.random.choice(['northeast', 'northwest', 'southeast', 'southwest'], NUM_SAMPLES, p=[0.25, 0.25, 0.27, 0.23])

# --- Charge calculation (realistic formula) ---
charges = []
for i in range(NUM_SAMPLES):
    age = ages[i]
    bmi = bmis[i]
    smoker = smokers[i]
    num_children = children_arr[i]
    region = regions[i]
    sex = sexes[i]

    # Base charge
    base = age * 260 + bmi * 340

    # Smoker premium
    if smoker == 'yes':
        smoker_premium = np.random.uniform(20000, 35000)
        # Higher BMI smokers pay even more
        if bmi > 30:
            smoker_premium += (bmi - 30) * 500
    else:
        smoker_premium = 0

    # Children cost
    child_cost = num_children * 500

    # Sex adjustment (small)
    sex_adj = 500 if sex == 'male' else 0

    # Region adjustment
    region_factors = {'northeast': 1.02, 'northwest': 1.00, 'southeast': 1.05, 'southwest': 0.98}
    region_mult = region_factors[region]

    # Age-squared factor for older individuals
    age_factor = (age / 64) ** 1.5 * 2000

    # Calculate total
    total = (base + smoker_premium + child_cost + sex_adj + age_factor) * region_mult

    # Add Gaussian noise (10% std)
    noise = np.random.normal(0, total * 0.08)
    total = max(1000, total + noise)

    charges.append(round(total, 2))

# --- Create DataFrame ---
df = pd.DataFrame({
    'age': ages,
    'sex': sexes,
    'bmi': bmis,
    'children': children_arr,
    'smoker': smokers,
    'region': regions,
    'charges': charges
})

# --- Save ---
output_path = os.path.join(os.path.dirname(__file__), 'insurance_data.csv')
df.to_csv(output_path, index=False)

print(f"Dataset generated: {output_path}")
print(f"Shape: {df.shape}")
print(f"\nSample rows:")
print(df.head(10).to_string(index=False))
print(f"\nCharges statistics:")
print(df['charges'].describe().to_string())
print(f"\nSmoker distribution: {df['smoker'].value_counts().to_dict()}")
print(f"Region distribution: {df['region'].value_counts().to_dict()}")
