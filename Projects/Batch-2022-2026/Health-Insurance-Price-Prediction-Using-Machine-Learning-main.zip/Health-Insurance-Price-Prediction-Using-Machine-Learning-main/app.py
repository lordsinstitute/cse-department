"""
Health Insurance Price Prediction — Flask Application
Port: 5015
"""
import os
import json
import sqlite3
from datetime import datetime
from functools import wraps

import numpy as np
import joblib
from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'insurepredict_secret_key_2025'

BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, 'insurance.db')

# --- Load ML artifacts ---
model = joblib.load(os.path.join(BASE_DIR, 'best_model.pkl'))
encoders = joblib.load(os.path.join(BASE_DIR, 'encoders.pkl'))
scaler = joblib.load(os.path.join(BASE_DIR, 'scaler.pkl'))
with open(os.path.join(BASE_DIR, 'models_info.json')) as f:
    models_info = json.load(f)


# --- Database ---
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')
    db.execute('''CREATE TABLE IF NOT EXISTS predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        age INTEGER NOT NULL,
        sex TEXT NOT NULL,
        bmi REAL NOT NULL,
        children INTEGER NOT NULL,
        smoker TEXT NOT NULL,
        region TEXT NOT NULL,
        predicted_charges REAL NOT NULL,
        rating INTEGER NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')
    # Seed admin
    existing = db.execute('SELECT id FROM users WHERE username = ?', ('admin',)).fetchone()
    if not existing:
        db.execute('INSERT INTO users (username, password, name, is_admin) VALUES (?, ?, ?, ?)',
                   ('admin', generate_password_hash('admin123'), 'Administrator', 1))
    db.commit()
    db.close()


init_db()


# --- Auth decorator ---
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to continue.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


# --- Prediction helpers ---
def get_cost_rating(charges):
    if charges < 10000:
        return min(max(int(charges / 3333) + 1, 1), 3), 'Low Cost', '#22c55e'
    elif charges < 25000:
        return min(max(int((charges - 10000) / 5000) + 4, 4), 6), 'Moderate Cost', '#eab308'
    elif charges < 40000:
        return min(max(int((charges - 25000) / 7500) + 7, 7), 8), 'High Cost', '#f97316'
    else:
        return min(max(int((charges - 40000) / 10000) + 9, 9), 10), 'Very High Cost', '#ef4444'


def predict_charges(age, sex, bmi, children, smoker, region):
    sex_encoded = encoders['sex'].transform([sex])[0]
    smoker_encoded = encoders['smoker'].transform([smoker])[0]
    region_encoded = encoders['region'].transform([region])[0]

    features = np.array([[age, sex_encoded, bmi, children, smoker_encoded, region_encoded]])
    features_scaled = scaler.transform(features)
    prediction = model.predict(features_scaled)[0]
    return max(0, prediction)


# --- Routes ---
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('home'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['name'] = user['name']
            session['is_admin'] = bool(user['is_admin'])
            flash(f'Welcome back, {user["name"]}!', 'success')
            return redirect(url_for('home'))
        flash('Invalid username or password.', 'danger')
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if not name or not username or not password:
            flash('All fields are required.', 'danger')
            return render_template('register.html')
        db = get_db()
        existing = db.execute('SELECT id FROM users WHERE username = ?', (username,)).fetchone()
        if existing:
            flash('Username already exists.', 'danger')
            return render_template('register.html')
        db.execute('INSERT INTO users (username, password, name) VALUES (?, ?, ?)',
                   (username, generate_password_hash(password), name))
        db.commit()
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))


@app.route('/home')
@login_required
def home():
    db = get_db()
    user_id = session['user_id']

    total_predictions = db.execute('SELECT COUNT(*) FROM predictions WHERE user_id = ?', (user_id,)).fetchone()[0]
    avg_row = db.execute('SELECT AVG(predicted_charges) FROM predictions WHERE user_id = ?', (user_id,)).fetchone()
    avg_charges = f"{avg_row[0]:,.0f}" if avg_row[0] else "0"

    recent = db.execute('SELECT * FROM predictions WHERE user_id = ? ORDER BY created_at DESC LIMIT 5',
                        (user_id,)).fetchall()

    # Admin stats
    total_users = 0
    all_predictions = 0
    if session.get('is_admin'):
        total_users = db.execute('SELECT COUNT(*) FROM users').fetchone()[0]
        all_predictions = db.execute('SELECT COUNT(*) FROM predictions').fetchone()[0]

    return render_template('home.html',
                           total_predictions=total_predictions,
                           avg_charges=avg_charges,
                           best_model=models_info['best_model'],
                           best_r2=models_info['best_r2'],
                           recent=recent,
                           total_users=total_users,
                           all_predictions=all_predictions)


@app.route('/predict', methods=['GET', 'POST'])
@login_required
def predict():
    result = None
    if request.method == 'POST':
        try:
            age = int(request.form['age'])
            sex = request.form['sex']
            bmi = float(request.form['bmi'])
            children = int(request.form['children'])
            smoker = request.form['smoker']
            region = request.form['region']

            # Validate
            if not (18 <= age <= 64):
                flash('Age must be between 18 and 64.', 'danger')
                return render_template('predict.html', result=None,
                                       best_model=models_info['best_model'],
                                       best_r2=models_info['best_r2'])
            if not (16.0 <= bmi <= 53.0):
                flash('BMI must be between 16.0 and 53.0.', 'danger')
                return render_template('predict.html', result=None,
                                       best_model=models_info['best_model'],
                                       best_r2=models_info['best_r2'])

            charges = predict_charges(age, sex, bmi, children, smoker, region)
            rating, label, color = get_cost_rating(charges)

            # Save to DB
            db = get_db()
            db.execute('''INSERT INTO predictions (user_id, age, sex, bmi, children, smoker, region, predicted_charges, rating)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                       (session['user_id'], age, sex, bmi, children, smoker, region, round(charges, 2), rating))
            db.commit()

            result = {
                'charges': round(charges, 2),
                'rating': rating,
                'label': label,
                'color': color,
                'age': age,
                'sex': sex,
                'bmi': bmi,
                'children': children,
                'smoker': smoker,
                'region': region
            }
        except Exception as e:
            flash(f'Prediction error: {str(e)}', 'danger')

    return render_template('predict.html', result=result,
                           best_model=models_info['best_model'],
                           best_r2=models_info['best_r2'])


@app.route('/history')
@login_required
def history():
    db = get_db()
    predictions = db.execute('SELECT * FROM predictions WHERE user_id = ? ORDER BY created_at DESC',
                             (session['user_id'],)).fetchall()
    return render_template('history.html', predictions=predictions)


@app.route('/dashboard')
@login_required
def dashboard():
    vis_dir = os.path.join(BASE_DIR, 'static', 'vis')
    eda_charts = sorted([f for f in os.listdir(vis_dir) if f.endswith('.png')]) if os.path.exists(vis_dir) else []

    model_names = list(models_info['results'].keys())
    r2_values = [models_info['results'][n]['r2'] for n in model_names]
    mae_values = [models_info['results'][n]['mae'] for n in model_names]
    rmse_values = [models_info['results'][n]['rmse'] for n in model_names]

    return render_template('dashboard.html',
                           models_info=models_info,
                           eda_charts=eda_charts,
                           model_names=model_names,
                           r2_values=r2_values,
                           mae_values=mae_values,
                           rmse_values=rmse_values)


@app.route('/about')
@login_required
def about():
    return render_template('about.html')


if __name__ == '__main__':
    app.run(debug=True, port=5015)
