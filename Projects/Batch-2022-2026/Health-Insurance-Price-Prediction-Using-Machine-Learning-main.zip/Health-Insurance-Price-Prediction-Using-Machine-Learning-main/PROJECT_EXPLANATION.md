# Health Insurance Price Prediction — Project Explanation

## What Does This Project Do?

Imagine you're thinking about getting health insurance. You want to know — how much will it cost me per year? The price depends on things like your age, whether you smoke, how much you weigh, and where you live. This project predicts your annual insurance charges instantly!

You fill in a simple form with 6 details about yourself, and the computer uses Machine Learning to predict how much your health insurance will cost per year. It also gives you a rating from 1 to 10 telling you if your cost is low, moderate, high, or very high — with color-coded labels so you can understand it at a glance.

## How Does It Work? (Step by Step)

### Step 1: Creating the Training Data

Before the computer can predict insurance prices, it needs to learn from examples. We create a dataset of 5,000 fake but realistic insurance records. Each record has:

- **Age** — How old the person is (18 to 64 years)
- **Sex** — Male or Female
- **BMI** — Body Mass Index, a number that relates height to weight (16 to 53)
- **Children** — Number of children covered (0 to 5)
- **Smoker** — Whether the person smokes (Yes or No)
- **Region** — Where they live (Northeast, Northwest, Southeast, Southwest)
- **Charges** — How much they pay per year (this is what we want to predict!)

The charges are calculated using a realistic formula:
- Older people pay more (age × $260)
- Higher BMI means higher costs (BMI × $340)
- Smokers pay A LOT more ($20,000 to $35,000 extra!)
- Each child adds about $500
- Different regions have slightly different costs

We also add some random variation (noise) so the data looks realistic — just like real insurance data.

### Step 2: Preparing the Data

Computers work with numbers, not words. So we need to convert text labels:
- **Sex:** male → 1, female → 0
- **Smoker:** yes → 1, no → 0
- **Region:** northeast → 0, northwest → 1, southeast → 2, southwest → 3

We also **scale** all the numbers so they're on the same range. This is called StandardScaler — it makes sure age (18-64) and BMI (16-53) are treated equally by the model instead of one dominating the other.

### Step 3: Training 6 Different Models

We try 6 different mathematical approaches to see which one predicts insurance prices best:

1. **Linear Regression** — Draws a straight line through the data. The simplest approach. Like drawing a trend line on a graph.

2. **Ridge Regression** — Like Linear Regression but with a penalty for making wild predictions. This prevents "overfitting" (memorizing the training data instead of learning patterns).

3. **Lasso Regression** — Similar to Ridge but can completely ignore unimportant features. It's like a feature selector built into the model.

4. **SVR (Support Vector Regression)** — Instead of drawing one line, it creates a "tube" around the data and tries to fit as many points inside it as possible.

5. **Random Forest** — Creates 100 different decision trees (like flowcharts), each making its own prediction. The final answer is the average of all 100 predictions. It's like asking 100 experts and taking their average opinion.

6. **Gradient Boosting** — Builds 200 decision trees one by one. Each new tree focuses on fixing the mistakes of the previous ones. It's like a student who reviews their wrong answers and keeps improving.

### Step 4: Picking the Winner

We test all 6 models on 1,500 records they've never seen before. We measure three things:

- **R² Score** — How much of the price variation the model explains (100% = perfect, 0% = useless). Our best model gets 92.60%!
- **MAE (Mean Absolute Error)** — On average, how far off the prediction is in dollars. Our best: $2,264.59
- **RMSE (Root Mean Square Error)** — Like MAE but penalizes big errors more. Our best: $3,306.26

The winner is **Ridge Regression** with an R² score of 92.60%.

### Step 5: Making a Prediction

When you fill in the form:
1. Your inputs are converted to numbers (same encoding as training)
2. The numbers are scaled (same scaler as training)
3. The best model predicts your annual insurance charges
4. A cost rating (1-10) is calculated:
   - **1-3:** Low Cost (green) — under $10,000
   - **4-6:** Moderate Cost (yellow) — $10,000 to $25,000
   - **7-8:** High Cost (orange) — $25,000 to $40,000
   - **9-10:** Very High Cost (red) — over $40,000

## What Does Each File Do?

| File | Purpose |
|------|---------|
| `app.py` | The main website — handles login, prediction form, history, dashboard |
| `generate_dataset.py` | Creates 5,000 fake insurance records for training |
| `train_model.py` | Trains 6 ML models, generates 8 charts, saves the best model |
| `templates/base.html` | Page layout with sky blue dark theme |
| `templates/login.html` | Login page |
| `templates/register.html` | Registration page |
| `templates/home.html` | Dashboard with prediction stats |
| `templates/predict.html` | Form to enter details + shows prediction result |
| `templates/history.html` | List of all past predictions |
| `templates/dashboard.html` | Side-by-side comparison of all 6 models with charts |
| `templates/about.html` | Project information and technology stack |

## What Is R² Score?

R² (R-squared) tells you how well the model's predictions match reality, on a scale from 0% to 100%.

- **R² = 100%:** The model predicts perfectly every time
- **R² = 92.60%:** The model explains 92.6% of why insurance prices vary (our best model!)
- **R² = 50%:** The model only explains half the variation
- **R² = 0%:** The model is no better than just guessing the average price

Think of it like a school grade — 92.6% is an A!

## What Is BMI?

BMI stands for **Body Mass Index**. It's calculated as:

**BMI = weight (kg) / height (m)²**

- Under 18.5: Underweight
- 18.5 – 24.9: Normal weight
- 25.0 – 29.9: Overweight
- 30.0 and above: Obese

Insurance companies use BMI because higher BMI is associated with more health risks, which means higher insurance costs.

## What Is Regression?

In Machine Learning, **regression** means predicting a number (like a price). This is different from **classification** which predicts a category (like positive/negative).

- **Regression example:** "This person's insurance will cost $25,000 per year"
- **Classification example:** "This email is spam or not spam"

Our project is a regression problem because we're predicting dollar amounts.

## How to Run It Yourself

1. Install Python 3.8+
2. Run `pip install -r requirements.txt`
3. Run `python generate_dataset.py` (creates training data)
4. Run `python train_model.py` (trains the models — takes ~30 seconds)
5. Run `python app.py` (starts the website)
6. Open http://localhost:5015 in your browser
7. Login with username: `admin`, password: `admin123`
8. Go to Predict, fill in the form, and click Predict!

## Why Does This Matter?

- Health insurance is one of the biggest personal expenses
- Understanding what affects your insurance price helps you make better health and financial decisions
- Insurance companies use similar ML models to set their prices
- The same techniques work for predicting car insurance, home insurance, loan amounts, and more
- Smoking is by far the biggest factor — smokers pay $20,000–$35,000 more per year!
- Age and BMI are the next most important factors
